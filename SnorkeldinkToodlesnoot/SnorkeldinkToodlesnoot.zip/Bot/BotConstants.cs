﻿namespace SnorkeldinkToodlesnoot.Bot
{
    public class BotConstants
    {
        public const string Floor = ".";
        public const string Wall = "x";
        public const string Player1 = "0";
        public const string Player2 = "1";
    }
}
