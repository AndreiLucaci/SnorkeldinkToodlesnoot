﻿using System;

namespace SnorkeldinkToodlesnoot.Bot
{
    public class ElapsedTimeException : Exception
    {
    }
}
