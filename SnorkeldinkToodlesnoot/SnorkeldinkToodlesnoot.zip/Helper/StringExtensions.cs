﻿namespace SnorkeldinkToodlesnoot.Helper
{
    public  static class StringExtensions
    {
        public static bool Free(this string value) => value == ".";
    }
}
